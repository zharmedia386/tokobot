@extends('layouts.master')
@section('title', 'User Profile')
@section('content')

<div class="row">
    <div class="col-lg-12">
        <div class="iq-main">
            <div class="card mb-0 iq-content rounded-bottom">
                <div class="d-flex flex-wrap align-items-center justify-content-between mx-3 my-3">
                    <div class="d-flex flex-wrap align-items-center">
                        <div class="profile-img22 position-relative me-3 mb-3 mb-lg-0">
                            <img src="../../assets/images/User-profile/1.png" class="img-fluid avatar avatar-100 avatar-rounded" alt="profile-image" />
                        </div>
                        <div class="d-flex align-items-center mb-3 mb-sm-0">
                            <div>
                                <h6 class="me-2 text-primary">Devon Lane</h6>
                                <span>
                                    <svg width="19" height="19" class="me-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M21 10.8421C21 16.9172 12 23 12 23C12 23 3 16.9172 3 10.8421C3 4.76697 7.02944 1 12 1C16.9706 1 21 4.76697 21 10.8421Z" stroke="#07143B" stroke-width="1.5" />
                                        <circle cx="12" cy="9" r="3" stroke="#07143B" stroke-width="1.5" />
                                    </svg>
                                    <small class="mb-0 text-dark">Lisbon, Portugal</small>
                                </span>
                            </div>
                            <div class="ms-4">
                                <p class="mb-0 text-dark">UI/UX Designer</p>
                                <p class="me-2 mb-0 text-dark">Hello@gmail.com</p>
                                <p class="mb-0 text-dark">Email</p>
                            </div>
                        </div>
                    </div>
                    <ul class="d-flex mb-0 text-center">
                        <li class="badge bg-primary py-2 me-2">
                            <p class="mb-3 mt-2">142</p>
                            <small class="mb-1 fw-normal">Reviews</small>
                        </li>
                        <li class="badge bg-primary py-2 me-2">
                            <p class="mb-3 mt-2">201</p>
                            <small class="mb-1 fw-normal">Photos</small>
                        </li>
                        <li class="badge bg-primary py-2 me-2">
                            <p class="mb-3 mt-2">3.1k</p>
                            <small class="mb-1 fw-normal">Followers</small>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="iq-header-img">
                <img src="../../assets/images/User-profile/01.png" alt="header" class="img-fluid w-100 rounded" style="object-fit: contain;" />
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">News</h4>
            </div>
            <div class="card-body py-0">
                <ul class="list-inline list-main">
                    <li class="py-3 d-flex">
                        <img src="../../assets/images/User-profile/10.png" class="img-fluid avatar avatar-60" alt="profile-image" />
                        <div class="ms-4">
                            <h6 class="heading-title fw-bolder mb-2">Pizza</h6>
                            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </div>
                    </li>
                    <li class="py-3 d-flex">
                        <img src="../../assets/images/User-profile/3.png" class="img-fluid avatar avatar-60" alt="profile-image" />
                        <div class="ms-4">
                            <h6 class="heading-title fw-bolder mb-2">Burger</h6>
                            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </div>
                    </li>
                    <li class="py-3 d-flex pb-0">
                        <img src="../../assets/images/User-profile/4.png" class="img-fluid avatar avatar-60" alt="profile-image" />
                        <div class="ms-4">
                            <h6 class="heading-title fw-bolder mb-2">Pasta</h6>
                            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title list-main">Online Order</h4>
            </div>
            <div class="card-body py-0">
                <ul class="list-inline list-main mb-0">
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Dineline</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Reviews</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Photos</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Followers</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Bookmarks</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Been there</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Achievements</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex justify-content-between">
                            <span class="heading-title text-dark">Blogs</span>
                            <span class="badge bg-primary px-3 rounded-pill d-flex align-items-center">1</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Online Order</h4>
            </div>
            <div class="card-body py-0">
                <ul class="list-inline list-main mb-0">
                    <li class="py-5">
                        <span class="heading-title text-dark">Favourite order</span>
                    </li>
                    <li class="py-5">
                        <span class="heading-title text-dark">Order history</span>
                    </li>
                    <li class="py-5">
                        <span class="heading-title text-dark">My address</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="profile-content tab-content">
            <div id="profile-feed" class="tab-pane fade active show">
                <div class="card">
                    <div class="card-header border-0 d-flex align-items-center justify-content-between pb-3 px-2">
                        <div class="header-title">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="media-support-user-img me-4">
                                    <img class="img-fluid avatar avatar-75 avatar-rounded" src="../../assets/images/User-profile/7.png" alt="" />
                                </div>
                                <div class="media-support-info mt-2">
                                    <h6 class="mb-0 heading-title fw-bolder">Wade Warren</h6>
                                    <small class="mb-0 text-primary">colleages</small>
                                </div>
                            </div>
                        </div>
                        <div class="dropdown text-dark">
                            <small id="dropdownMenuButton8" data-bs-toggle="dropdown" aria-expanded="false" role="button">
                                29 mins
                                <svg width="12" height="6" class="ms-3" viewBox="0 0 14 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 6L0.0717964 0L13.9282 0L7 6Z" fill="#07143B" />
                                </svg>
                            </small>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton7">
                                <a class="dropdown-item" href="javascript:void(0);">Action</a>
                                <a class="dropdown-item" href="javascript:void(0);">Another action</a>
                                <a class="dropdown-item" href="javascript:void(0);">Something else here</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="user-post">
                            <img src="../../assets/images/User-profile/9.png" alt="post-image" class="img-fluid" />
                        </div>
                        <div class="comment-area p-4">
                            <div class="d-flex flex-wrap justify-content-between align-items-center px-3 pt-0">
                                <div class="d-flex align-items-center text-dark">
                                    <div class="d-flex align-items-center message-icon me-3">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M12.1,18.55L12,18.65L11.89,18.55C7.14,14.24 4,11.39 4,8.5C4,6.5 5.5,5 7.5,5C9.04,5 10.54,6 11.07,7.36H12.93C13.46,6 14.96,5 16.5,5C18.5,5 20,6.5 20,8.5C20,11.39 16.86,14.24 12.1,18.55M16.5,3C14.76,3 13.09,3.81 12,5.08C10.91,3.81 9.24,3 7.5,3C4.42,3 2,5.41 2,8.5C2,12.27 5.4,15.36 10.55,20.03L12,21.35L13.45,20.03C18.6,15.36 22,12.27 22,8.5C22,5.41 19.58,3 16.5,3Z"
                                            />
                                        </svg>
                                        <span class="ms-3">140</span>
                                    </div>
                                    <div class="d-flex align-items-center feather-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M9,22A1,1 0 0,1 8,21V18H4A2,2 0 0,1 2,16V4C2,2.89 2.9,2 4,2H20A2,2 0 0,1 22,4V16A2,2 0 0,1 20,18H13.9L10.2,21.71C10,21.9 9.75,22 9.5,22V22H9M10,16V19.08L13.08,16H20V4H4V16H10Z"
                                            />
                                        </svg>
                                        <span class="ms-3">140</span>
                                    </div>
                                </div>
                                <div class="share-block d-flex align-items-center feather-icon">
                                    <a href="javascript:void(0);" data-bs-toggle="offcanvas" data-bs-target="#share-btn" aria-controls="share-btn">
                                        <span class="ms-2">
                                            <svg width="18" class="me-1" viewBox="0 0 24 24">
                                                <path
                                                    fill="currentColor"
                                                    d="M18 16.08C17.24 16.08 16.56 16.38 16.04 16.85L8.91 12.7C8.96 12.47 9 12.24 9 12S8.96 11.53 8.91 11.3L15.96 7.19C16.5 7.69 17.21 8 18 8C19.66 8 21 6.66 21 5S19.66 2 18 2 15 3.34 15 5C15 5.24 15.04 5.47 15.09 5.7L8.04 9.81C7.5 9.31 6.79 9 6 9C4.34 9 3 10.34 3 12S4.34 15 6 15C6.79 15 7.5 14.69 8.04 14.19L15.16 18.34C15.11 18.55 15.08 18.77 15.08 19C15.08 20.61 16.39 21.91 18 21.91S20.92 20.61 20.92 19C20.92 17.39 19.61 16.08 18 16.08M18 4C18.55 4 19 4.45 19 5S18.55 6 18 6 17 5.55 17 5 17.45 4 18 4M6 13C5.45 13 5 12.55 5 12S5.45 11 6 11 7 11.45 7 12 6.55 13 6 13M18 20C17.45 20 17 19.55 17 19S17.45 18 18 18 19 18.45 19 19 18.55 20 18 20Z"
                                                ></path>
                                            </svg>
                                            99 Share
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <hr class="bg-primary my-4" />
                            <p class="px-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Id quam tortor nec arcu. Euismod neque ultricies eget adipiscing condimentum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Id quam tortor
                                nec arcu. Euismod neque ultricies eget adipiscing condimentum.
                            </p>
                            <hr class="bg-primary my-4" />
                            <ul class="list-inline p-0 m-0">
                                <li class="py-3 px-2 pt-0">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid avatar avatar-55 avatar-rounded" src="../../assets/images/User-profile/6.png" alt="" />
                                        <div class="ms-3">
                                            <h6 class="mb-1 heading-title fw-bolder">Paul Molive</h6>
                                            <p class="mb-1">Lorem ipsum dolor sit amet</p>
                                            <div class="d-flex flex-wrap align-items-center mb-1">
                                                <a href="javascript:void(0);" class="me-3">
                                                    <svg width="20" height="20" class="me-2" viewBox="0 0 24 24">
                                                        <path
                                                            fill="currentColor"
                                                            d="M12.1,18.55L12,18.65L11.89,18.55C7.14,14.24 4,11.39 4,8.5C4,6.5 5.5,5 7.5,5C9.04,5 10.54,6 11.07,7.36H12.93C13.46,6 14.96,5 16.5,5C18.5,5 20,6.5 20,8.5C20,11.39 16.86,14.24 12.1,18.55M16.5,3C14.76,3 13.09,3.81 12,5.08C10.91,3.81 9.24,3 7.5,3C4.42,3 2,5.41 2,8.5C2,12.27 5.4,15.36 10.55,20.03L12,21.35L13.45,20.03C18.6,15.36 22,12.27 22,8.5C22,5.41 19.58,3 16.5,3Z"
                                                        />
                                                    </svg>
                                                    like
                                                </a>
                                                <a href="javascript:void(0);" class="me-3">
                                                    <svg width="20" height="20" class="me-2" viewBox="0 0 24 24">
                                                        <path
                                                            fill="currentColor"
                                                            d="M8,9.8V10.7L9.7,11C12.3,11.4 14.2,12.4 15.6,13.7C13.9,13.2 12.1,12.9 10,12.9H8V14.2L5.8,12L8,9.8M10,5L3,12L10,19V14.9C15,14.9 18.5,16.5 21,20C20,15 17,10 10,9"
                                                        />
                                                    </svg>
                                                    reply
                                                </a>
                                                <a href="javascript:void(0);" class="me-3">translate</a>
                                                <span> 5 min </span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="py-3 px-2">
                                    <div class="d-flex align-items-center">
                                        <img class="img-fluid avatar avatar-55 avatar-rounded" src="../../assets/images/User-profile/7.png" alt="" />
                                        <div class="ms-3">
                                            <h6 class="mb-1 heading-title fw-bolder">Robert Fox</h6>
                                            <p class="mb-1">Lorem ipsum dolor sit amet</p>
                                            <div class="d-flex flex-wrap align-items-center">
                                                <a href="javascript:void(0);" class="me-3">
                                                    <svg width="20" height="20" class="me-2" viewBox="0 0 24 24">
                                                        <path
                                                            fill="currentColor"
                                                            d="M12.1,18.55L12,18.65L11.89,18.55C7.14,14.24 4,11.39 4,8.5C4,6.5 5.5,5 7.5,5C9.04,5 10.54,6 11.07,7.36H12.93C13.46,6 14.96,5 16.5,5C18.5,5 20,6.5 20,8.5C20,11.39 16.86,14.24 12.1,18.55M16.5,3C14.76,3 13.09,3.81 12,5.08C10.91,3.81 9.24,3 7.5,3C4.42,3 2,5.41 2,8.5C2,12.27 5.4,15.36 10.55,20.03L12,21.35L13.45,20.03C18.6,15.36 22,12.27 22,8.5C22,5.41 19.58,3 16.5,3Z"
                                                        />
                                                    </svg>
                                                    like
                                                </a>
                                                <a href="javascript:void(0);" class="me-3">
                                                    <svg width="20" height="20" class="me-2" viewBox="0 0 24 24">
                                                        <path
                                                            fill="currentColor"
                                                            d="M8,9.8V10.7L9.7,11C12.3,11.4 14.2,12.4 15.6,13.7C13.9,13.2 12.1,12.9 10,12.9H8V14.2L5.8,12L8,9.8M10,5L3,12L10,19V14.9C15,14.9 18.5,16.5 21,20C20,15 17,10 10,9"
                                                        />
                                                    </svg>
                                                    reply
                                                </a>
                                                <a href="javascript:void(0);" class="me-3">translate</a>
                                                <span> 5 min </span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <form class="comment-text d-flex align-items-center mt-3" action="javascript:void(0);">
                                <input type="text" class="form-control rounded" placeholder="Lovely!" />
                                <div class="comment-attagement d-flex">
                                    <a href="javascript:void(0);" class="me-4 text-body">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M20,12A8,8 0 0,0 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12M22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12M10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8C9.3,8 10,8.7 10,9.5M17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8C16.3,8 17,8.7 17,9.5M12,17.23C10.25,17.23 8.71,16.5 7.81,15.42L9.23,14C9.68,14.72 10.75,15.23 12,15.23C13.25,15.23 14.32,14.72 14.77,14L16.19,15.42C15.29,16.5 13.75,17.23 12,17.23Z"
                                            />
                                        </svg>
                                    </a>
                                    <a href="javascript:void(0);" class="text-body me-3">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M20,4H16.83L15,2H9L7.17,4H4A2,2 0 0,0 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V6A2,2 0 0,0 20,4M20,18H4V6H8.05L9.88,4H14.12L15.95,6H20V18M12,7A5,5 0 0,0 7,12A5,5 0 0,0 12,17A5,5 0 0,0 17,12A5,5 0 0,0 12,7M12,15A3,3 0 0,1 9,12A3,3 0 0,1 12,9A3,3 0 0,1 15,12A3,3 0 0,1 12,15Z"
                                            />
                                        </svg>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-between pb-4">
                        <div class="header-title">
                            <div class="d-flex flex-wrap align-items-center">
                                <div class="media-support-user-img me-3">
                                    <img class="img-fluid avatar avatar-75 avatar-rounded" src="../../assets/images/User-profile/8.png" alt="" />
                                </div>
                                <div class="media-support-info mt-2">
                                    <h6 class="mb-0 heading-title fw-bolder">Wade Warren</h6>
                                    <small class="mb-0 text-primary">colleages</small>
                                </div>
                            </div>
                        </div>
                        <div class="dropdown text-dark">
                            <small id="dropdownMenuButton7" data-bs-toggle="dropdown" aria-expanded="false" role="button">
                                29 mins
                                <svg width="12" height="6" class="ms-3" viewBox="0 0 14 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 6L0.0717964 0L13.9282 0L7 6Z" fill="#07143B" />
                                </svg>
                            </small>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton7">
                                <a class="dropdown-item" href="javascript:void(0);">Action</a>
                                <a class="dropdown-item" href="javascript:void(0);">Another action</a>
                                <a class="dropdown-item" href="javascript:void(0);">Something else here</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <p class="p-4 mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi nulla dolor, ornare at commodo non, feugiat non nisi. Phasellus faucibus mollis pharetra. Proin blandit ac massa sed rhoncus</p>
                        <div class="comment-area p-4 pt-0">
                            <hr class="mt-0" />
                            <div class="d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex align-items-center text-dark">
                                    <div class="d-flex align-items-center message-icon me-3">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M12.1,18.55L12,18.65L11.89,18.55C7.14,14.24 4,11.39 4,8.5C4,6.5 5.5,5 7.5,5C9.04,5 10.54,6 11.07,7.36H12.93C13.46,6 14.96,5 16.5,5C18.5,5 20,6.5 20,8.5C20,11.39 16.86,14.24 12.1,18.55M16.5,3C14.76,3 13.09,3.81 12,5.08C10.91,3.81 9.24,3 7.5,3C4.42,3 2,5.41 2,8.5C2,12.27 5.4,15.36 10.55,20.03L12,21.35L13.45,20.03C18.6,15.36 22,12.27 22,8.5C22,5.41 19.58,3 16.5,3Z"
                                            />
                                        </svg>
                                        <span class="ms-2">140</span>
                                    </div>
                                    <div class="d-flex align-items-center feather-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M9,22A1,1 0 0,1 8,21V18H4A2,2 0 0,1 2,16V4C2,2.89 2.9,2 4,2H20A2,2 0 0,1 22,4V16A2,2 0 0,1 20,18H13.9L10.2,21.71C10,21.9 9.75,22 9.5,22V22H9M10,16V19.08L13.08,16H20V4H4V16H10Z"
                                            />
                                        </svg>
                                        <span class="ms-2">140</span>
                                    </div>
                                </div>
                                <div class="share-block d-flex align-items-center feather-icon">
                                    <a href="javascript:void(0);" data-bs-toggle="offcanvas" data-bs-target="#share-btn" aria-controls="share-btn">
                                        <span class="ms-1">
                                            <svg width="18" class="me-1" viewBox="0 0 24 24">
                                                <path
                                                    fill="currentColor"
                                                    d="M18 16.08C17.24 16.08 16.56 16.38 16.04 16.85L8.91 12.7C8.96 12.47 9 12.24 9 12S8.96 11.53 8.91 11.3L15.96 7.19C16.5 7.69 17.21 8 18 8C19.66 8 21 6.66 21 5S19.66 2 18 2 15 3.34 15 5C15 5.24 15.04 5.47 15.09 5.7L8.04 9.81C7.5 9.31 6.79 9 6 9C4.34 9 3 10.34 3 12S4.34 15 6 15C6.79 15 7.5 14.69 8.04 14.19L15.16 18.34C15.11 18.55 15.08 18.77 15.08 19C15.08 20.61 16.39 21.91 18 21.91S20.92 20.61 20.92 19C20.92 17.39 19.61 16.08 18 16.08M18 4C18.55 4 19 4.45 19 5S18.55 6 18 6 17 5.55 17 5 17.45 4 18 4M6 13C5.45 13 5 12.55 5 12S5.45 11 6 11 7 11.45 7 12 6.55 13 6 13M18 20C17.45 20 17 19.55 17 19S17.45 18 18 18 19 18.45 19 19 18.55 20 18 20Z"
                                                ></path>
                                            </svg>
                                            99 Share
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <form class="comment-text d-flex align-items-center mt-3" action="javascript:void(0);">
                                <input type="text" class="form-control rounded" placeholder="Lovely!" />
                                <div class="comment-attagement d-flex">
                                    <a href="javascript:void(0);" class="me-4 text-body">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M20,12A8,8 0 0,0 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12M22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12M10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8C9.3,8 10,8.7 10,9.5M17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8C16.3,8 17,8.7 17,9.5M12,17.23C10.25,17.23 8.71,16.5 7.81,15.42L9.23,14C9.68,14.72 10.75,15.23 12,15.23C13.25,15.23 14.32,14.72 14.77,14L16.19,15.42C15.29,16.5 13.75,17.23 12,17.23Z"
                                            />
                                        </svg>
                                    </a>
                                    <a href="javascript:void(0);" class="text-body me-3">
                                        <svg width="20" height="20" viewBox="0 0 24 24">
                                            <path
                                                fill="currentColor"
                                                d="M20,4H16.83L15,2H9L7.17,4H4A2,2 0 0,0 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V6A2,2 0 0,0 20,4M20,18H4V6H8.05L9.88,4H14.12L15.95,6H20V18M12,7A5,5 0 0,0 7,12A5,5 0 0,0 12,17A5,5 0 0,0 17,12A5,5 0 0,0 12,7M12,15A3,3 0 0,1 9,12A3,3 0 0,1 12,9A3,3 0 0,1 15,12A3,3 0 0,1 12,15Z"
                                            />
                                        </svg>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header">
                <div class="header-title">
                    <h4 class="card-title">About</h4>
                </div>
            </div>
            <div class="card-body">
                <p>Lorem ipsum dolor sit amet, contur adipiscing elit.<span class="text-dark">Lorem ipsum dolor sit amet</span></p>
                <div class="mb-1">Email: <a href="#" class="">nikjone@demoo.com</a></div>
                <div class="mb-1">Phone: <a href="#" class="ms-1">001 2351 256 12</a></div>
                <div>Location: <span class="ms-1 text-primary">USA</span></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Suggestions</h4>
            </div>
            <div class="card-body py-0">
                <ul class="list-inline list-main p-0 mb-0">
                    <li class="py-5">
                        <div class="d-flex align-items-center">
                            <img src="../../assets/images/User-profile/2.png" class="img-fluid avatar avatar-80" alt="profile-image" />
                            <div class="ms-3">
                                <h6 class="mb-2 heading-title fw-bolder">Pizza</h6>
                                <p class="mb-0">345+ Options</p>
                            </div>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex align-items-center">
                            <img src="../../assets/images/User-profile/11.png" class="img-fluid avatar avatar-80" alt="profile-image" />
                            <div class="ms-3">
                                <h6 class="mb-2 heading-title fw-bolder">Pizza</h6>
                                <p class="mb-0">345+ Options</p>
                            </div>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex align-items-center">
                            <img src="../../assets/images/User-profile/12.png" class="img-fluid avatar avatar-80" alt="profile-image" />
                            <div class="ms-3">
                                <h6 class="mb-2 heading-title fw-bolder">Burger</h6>
                                <p class="mb-0">260+ Options</p>
                            </div>
                        </div>
                    </li>
                    <li class="py-5">
                        <div class="d-flex align-items-center">
                            <img src="../../assets/images/User-profile/13.png" class="img-fluid avatar avatar-80" alt="profile-image" />
                            <div class="ms-3">
                                <h6 class="mb-2 heading-title fw-bolder">Pasta</h6>
                                <p class="mb-0">250+ Options</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card" style="background: url('../../assets/images/User-profile/02.png'); background-size: cover;">
            <div class="card-body">
                <div class="div">
                    <div class="div">
                        <h2 class="text-primary text-special">
                            Today’s<br />
                            Special<br />
                            Menu
                        </h2>
                    </div>
                    <div class="text-center">
                        <div class="position-relative">
                            <img src="../../assets/images/User-profile/5.png" class="img-fluid mt-5 mb-5 rounded-2" alt="profile-image" />
                            <div class="iq-offer text-dark p-2 rounded-pill border border-primary">
                                <span>50%</span><br />
                                <span class="text-uppercase">Off</span>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary rounded-pill mt-3">ORDER NOW!</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="offcanvas offcanvas-bottom share-offcanvas" tabindex="-1" id="share-btn" aria-labelledby="shareBottomLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="shareBottomLabel">Share</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body small">
        <div class="d-flex flex-wrap align-items-center">
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/08.png" class="img-fluid rounded mb-2" alt="" />
                <h6>Facebook</h6>
            </div>
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/09.png" class="img-fluid rounded mb-2" alt="" />
                <h6>Twitter</h6>
            </div>
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/10.png" class="img-fluid rounded mb-2" alt="" />
                <h6>Instagram</h6>
            </div>
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/11.png" class="img-fluid rounded mb-2" alt="" />
                <h6>Google Plus</h6>
            </div>
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/13.png" class="img-fluid rounded mb-2" alt="" />
                <h6>In</h6>
            </div>
            <div class="text-center me-3 mb-3">
                <img src="../../assets/images/brands/12.png" class="img-fluid rounded mb-2" alt="" />
                <h6>YouTube</h6>
            </div>
        </div>
    </div>
</div>

@endsection